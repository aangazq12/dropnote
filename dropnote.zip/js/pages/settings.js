/* =========================
   SETTINGS v1
   (info-only)
   ========================= */

(function () {
  // No interactive logic yet
})();